﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(5);
            Console.WriteLine(10);
            Console.WriteLine(21);

            Console.ReadLine();
        }
    }
}
